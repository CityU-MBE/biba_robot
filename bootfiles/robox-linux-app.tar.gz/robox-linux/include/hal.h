/* 
 * Copyright (C) 2004
 * Swiss Federal Institute of Technology, Lausanne. All rights reserved.
 * 
 * Developed at the Autonomous Systems Lab.
 * Visit our homepage at http://asl.epfl.ch/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


/** \file hal.h
 * \brief Definition of data structures and functions provided by HAL to kernel and user space
 */

#ifndef __HAL_H__
#define __HAL_H__

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#ifdef __KERNEL__
#include <rtai.h>
#include <rtai_sem.h>
#include <rtai_sched.h>
#else
#include <sys/time.h>
#include <stdint.h>
#endif



/** \brief Data structure for getting bumpers states */
struct hal_bumper_data_s {
  struct timespec timestamp;
  /** Number of available bumpers */
  uint8_t   count;   
  /** Bitfield representing bumpers state. If bit i is set to 1,
   *  bumper i is pressed */
  uint32_t  bumpers; 
};

/** \brief Data structure for getting and setting wheels speed */
struct hal_speed_data_s {
  struct timespec timestamp;
  /** Speed on left wheel [rad/s]. If the value is positive, the wheel turns towards
   *  posisitve x   */
  double speed_l;
  /** Speed on right wheel [rad/s]. If the value is positive, the wheel turns towards
   *  posisitve x   */
  double speed_r;
};

typedef uint16_t hal_laser_range_t;

/** \brief Data structure for getting one complete scan from a laser channel */
struct hal_laser_data_s {
  struct timespec timestamp;
  /** Bumber of ranges in the scan */
  uint16_t nranges; 
  /** Pointer on range values in [millimeter]. It must point to a memory area
   *  of size nranges*sizeof(hal_laser_range_t) allocated by the caller. Scans
   *  proceed counterclockwise about the laser */
  hal_laser_range_t *ranges; 
};

/** \brief Data structure for getting and setting odometry values */
struct hal_odometry_data_s {
  struct timespec timestamp;
  /** x value in [m] */
  double x; 
  /** y value in [m] */
  double y;
  /** theta value in [rad] */
  double theta;
  double cov_matrix[3][3];
};

/** Bit set to 1 in security bitfield if supervisor stop is on */
#define HAL_SECURITY_SUPERVISOR_STOP 1
/** Bit set to 1 in security bitfield if emergency stop is on */
#define HAL_SECURITY_EMERGENCY_STOP  2 
/** Bit set to 1 in security bitfield if battery level is low */
#define HAL_SECURITY_BATTERY_LOW     4 
/** Bit set to 1 in security bitfield if battery level is too low to move */
#define HAL_SECURITY_BATTERY_TOO_LOW 8 

/** \brief Data structure for getting security state */
struct hal_security_data_s {
  struct timespec timestamp;
  /** Bitfield representing the current state */
  uint32_t state;
};



typedef uint32_t hal_motor_t;
/** \brief Data structure for setting motor value on a channel */
struct hal_motor_data_s
{
  struct timespec timestamp;
  hal_motor_t value;
};

typedef uint32_t hal_encoder_t;
/** \brief Data structure for getting encoder value on a channel */
struct hal_encoder_data_s 
{
  struct timespec timestamp; 
  hal_encoder_t encoder;
};


/** \brief Get one complete scan from a laser channel.
 *
 *  The buffer for receiving the ranges has to be provided by the caller. The scan size
 *  can be obtained by calling hal_laser_get_nranges().
 *  data->nranges has to be set by the caller to the length (number of hal_laser_range_t)
 *  of the buffer (data->ranges) that is provided. If the buffer length is
 *  to small to receive a complete scan, HAL returns an error. Otherwise, HAL sets 
 *  data->nranges to the number of valid ranges returned. */
int hal_laser_get_channel(uint8_t channel, struct hal_laser_data_s *data);

/** \brief Get scan length (number of ranges) from a laser channel.
 * 
 *  The obtained value represents the size of the buffer (number of hal_laser_range_t)
 *  to be provided before calling hal_laser_get_channel() */
int hal_laser_get_nranges(uint8_t channel, uint16_t *nranges);

/** \brief Get bumpers states for all available bumpers */
int hal_bumper_get(struct hal_bumper_data_s *data);

int hal_speed_setpidparams(double kP, double kI, double kD, double arw);
int hal_speed_getpidparams(double *kP, double *kI, double *kD, double *arw);

/** \brief Get current speed on left and right wheels */
int hal_speed_get(struct hal_speed_data_s *data);
/** \brief Get speed on left and right wheels */
int hal_speed_set(struct hal_speed_data_s data);


/** \brief Get current odometry data*/
int hal_odometry_get(struct hal_odometry_data_s *data);
/** \brief Get odometry data */
int hal_odometry_set(struct hal_odometry_data_s data);


/** \brief Get current security states */
int hal_security_get(struct hal_security_data_s *data);

/** \brief Get encoder value on a channel*/
int hal_encoder_get_channel(uint8_t channel, struct hal_encoder_data_s *data);
/** \brief Compute delta between two encoders value */
int hal_encoder_delta(hal_encoder_t old_value, hal_encoder_t new_value);
/** Temporary define until we find a better way to do it */
#define HAL_ENCODER_TO_RAD(X)  X/(4.0*500.0*50.0)*2.0*M_PI

int hal_motor_get_channel(uint8_t channel, struct hal_motor_data_s *data);
int hal_motor_set_channel(uint8_t channel, hal_motor_t value);

/** \brief Get current time in second and nanosecond */
int hal_time_get(struct timespec *time);


int hal_security_get_proc(char *buf);
int hal_speed_get_proc(char *buf);


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
