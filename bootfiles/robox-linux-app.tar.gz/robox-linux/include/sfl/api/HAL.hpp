/* 
 * Copyright (C) 2004
 * Swiss Federal Institute of Technology, Lausanne. All rights reserved.
 * 
 * Developed at the Autonomous Systems Lab.
 * Visit our homepage at http://asl.epfl.ch/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


#ifndef SUNFLOWER_HAL_HPP
#define SUNFLOWER_HAL_HPP


#include <cstddef>


/** Declared in <time.h> but don't use system clock: The HAL is used
    as central "wall clock" so that simulation can freeze time when
    needed. */
struct timespec;


namespace sfl {

  
  /**
     This class serves as proxy for the hardware abstraction
     layer. This additional indirection makes it possible to keep the
     object-oriented parts of sunflower sort of independent from the
     HAL implementation. For example, it makes it easy to switch
     between Fred's HAL of Robox and Smartease, using GenoM, or
     working with the nepumuk simulator - all with one and the same
     sunflower code.

     \note If you have an existing hardware abstraction layer coded in
     C, have a look at sfl_cwrap::cwrapHAL in the cwrap/ directory. It
     takes a collection of function pointers in a struct cwrap_hal_s
     as ctor argument, which simplifies interfacing your C
     implementation with libsunflower.
  */
  
  class HAL
  {
  public:
    virtual ~HAL() { }
    
    /** \return 0 on success. */
    virtual int time_get(struct ::timespec * stamp) = 0;
    
    /** \return 0 on success. */
    virtual int odometry_set(double x, double y, double theta,
			     double sxx, double syy, double stt,
			     double sxy, double sxt, double syt) = 0;
    
    /** \return 0 on success. */
    virtual int odometry_get(struct ::timespec * stamp,
			     double * x, double * y, double * theta,
			     double * sxx, double * syy, double * stt,
			     double * sxy, double * sxt, double * syt) = 0;
    
    /** \return 0 on success. */
    virtual int speed_set(double qdl, double qdr) = 0;
    
    /** \return 0 on success. */
    virtual int speed_get(double * qdl, double * qdr) = 0;
    
    /** \note rho_len is input AND output: If there are fewer scan
	points than (in) rho_len available, this is reflected by the
	(out) value of rho_len. rho[ii] at ii >= (in) rho_len ARE NOT
	UPDATED, it is up to the caller to do something sensible such
	as setting them to max range or ignoring them. If there are
	MORE than (in) rho_len data points, the scan data is simply
	truncated.
	\return 0 on success. */
    virtual int scan_get(int channel, double * rho,
			 /** IN: size of rho[], OUT: scan length */
			 size_t * rho_len,
			 struct ::timespec * t0, struct ::timespec * t1) = 0;
  };
  
}

#endif // SUNFLOWER_HAL_HPP
